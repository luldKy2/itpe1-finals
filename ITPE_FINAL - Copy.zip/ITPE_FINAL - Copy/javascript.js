let cart = [];
let totalPrice = 0;

function addToCart(productName, productPrice) {
    // Add the product to the cart
    cart.push({ name: productName, price: productPrice });
    
    // Update the total price
    totalPrice += productPrice;
    
    // Update the cart count
    document.getElementById('cart-count').innerText = cart.length;
    
    // Update the total price display in the modal
    document.getElementById('total-price').innerText = totalPrice.toFixed(2);
    
    // Optionally, show a modal or alert to confirm the addition
    alert(`${productName} has been added to your cart.`);
}

function completePurchase() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const purchaseDate = document.getElementById('purchase-date').value;

    // Validate input fields
    if (name && email && purchaseDate) {
        // Display a confirmation message
        alert(`Thank you for your purchase, ${name}! Your total is $${totalPrice.toFixed(2)}. A confirmation email will be sent to ${email}.`);
        
        // Reset cart
        cart = [];
        totalPrice = 0;
        document.getElementById('cart-count').innerText = 0;
        document.getElementById('total-price').innerText = '0.00';
        
        // Clear input fields
        document.getElementById('name').value = '';
        document.getElementById('email').value = '';
        document.getElementById('purchase-date').value = '';
        
        closeCheckoutModal(); // Close the modal if it's open
    } else {
        alert('Please fill in all fields.');
    }
}

function closeCheckoutModal() {
    document.getElementById('checkout-modal').style.display = 'none';
}

// Function to open the checkout modal
function openCheckoutModal() {
    document.getElementById('checkout-modal').style.display = 'block';
}

// Add an event listener to open the modal when the cart is clicked
document.querySelector('.cart').addEventListener('click', openCheckoutModal);